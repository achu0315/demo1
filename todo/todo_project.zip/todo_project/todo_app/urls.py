from . import views
from django.urls import path
app_name='appname'

urlpatterns = [

    path('',views.demo,name='demo'),
    # path('detail',views.detail,name='detail')
    path('delete/<int:taskid>/',views.delete,name='delete'),
    path('update/<int:id>/',views.update,name='update')
]
