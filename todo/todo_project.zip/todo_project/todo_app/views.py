from django.http import HttpResponse
from django.shortcuts import render, redirect

from todo_app.models import task
from . form import todoform


# Create your views here.
def demo(request):
    tasks = task.objects.all()
    if request.method == 'POST':
        name = request.POST.get('name','')
        priority = request.POST.get('priority','')
        date=request.POST.get('date','')
        todo = task(name=name, priority=priority, date=date)
        todo.save()
    return render(request, 'index.html',{'tas':tasks})


# def detail(request):
#
#     return render(request, 'detail.html', {'tas': tasks})

def delete(request,taskid):
    task1=task.objects.get(id=taskid)
    if request.method=='POST':
        task1.delete()
        return redirect('/')

    return render(request,'delete.html')

def update(request,id):
    up = task.objects.get(id=id)
    upf = todoform(request.POST or None, instance=up)

    if upf.is_valid():
        upf.save()
        return redirect('/')
    return render(request,'update.html',{'up':up,'upf':upf})



